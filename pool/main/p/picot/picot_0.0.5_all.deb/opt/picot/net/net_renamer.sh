#!/usr/bin/env bash
set -Eeuo pipefail

function log() {
  echo >&2 -e "[$(date +"%Y-%m-%d %H:%M:%S")] ${1-}"
}

function die() {
  local msg=$1
  local code=${2:-1}
  log "[ERROR] $msg"
  exit "$code"
}

if [ ! $(id -u) -eq 0 -o ! $(id -g) -eq 0 ]; then
  die "Run script with root privileges"
fi

SDWAN_DEVICE=${SDWAN_DEVICE:-}

if [[ "${SDWAN_DEVICE}" != "cpe" ]]; then
  log "Device not CPE"
fi

usage() {
  cat <<EOF
Usage: $(basename "${BASH_SOURCE[0]}") [-h] [-v] [-d Device]

Available options:
-p, --prefix            Set prefix for name ethernet ports
-h, --help              Print this help and exit
-v, --verbose           Print script debug info
EOF
}

function parse_params() {
  SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" &>/dev/null && pwd -P)
  NET_LIST=$(networkctl list 2>/dev/null | grep -vE "lo|wwan|wlan" | sed '1d' | sed '/^$/d' | sed '$d' | awk '{print $2}')
  PREFIX=""

  while :; do
    case "${1-}" in
    -p | --prefix)
      PREFIX="${2-}"
      shift
      ;;
    -v | --verbose) set -x ;;
    -h | --help) usage exit 0 ;;
    ?*) die "Unknown option: $1" ;;
    *) break ;;
    esac
    shift
  done

  return 0
}

parse_params "$@"

# Set prefix for ports
if [ "$PREFIX" == "" ]; then
  PREFIX=$(whiptail --title "Настройка портов" --inputbox "Введите префикс для портов" 8 39 port 3>&1 1>&2 2>&3)
  exitstatus=$?
  if [ $exitstatus != 0 ]; then
    die "User selected Cancel"
  fi
fi

function get_mac() {
  cat "/sys/class/net/$1/address"
}

function rename_port() {
  log "Rename port $1 to $PREFIX$2"
  LINK_FILE_SUFFIX=$(get_mac "$1" | sed "s|:||g")
  cat <<EOF >/etc/systemd/network/20-"$LINK_FILE_SUFFIX".link
[Match]
MACAddress=$(get_mac "$1")

[Link]
Name=${PREFIX}$2
EOF
  [ $? == 0 ] || die "Ошибка создания файла: /etc/systemd/network/20-$LINK_FILE_SUFFIX.link"
}

function generate_links() {
  i=1
  for net_name in $(echo -e "$1"); do
    rename_port "$net_name" $i
    i=$((i + 1))
  done
}

function generate_config() {
  rm -rf /etc/network/interfaces.d/*
  i=1
  for net_name in $(echo -e "$1"); do
    if [ $i -eq 1 ]; then
      cat <<EOF >/etc/network/interfaces.d/$PREFIX$i
auto $PREFIX$i
allow-hotplug $PREFIX$i
iface $PREFIX$i inet static
    address 192.168.1.1
    netmask 255.255.255.0
EOF
    else
      cat <<EOF >/etc/network/interfaces.d/$PREFIX$i
auto $PREFIX$i
allow-hotplug $PREFIX$i
iface $PREFIX$i inet manual
EOF
    fi
    i=$((i + 1))
  done
}

tmpdir=$(mktemp -d)
cd "$tmpdir" || die "Could not change directory"

if [ -z "$(ls -A /etc/network/interfaces.d/)" ]; then
  log "Generate default config for network"
  for net_name in $NET_LIST; do
    cat >/etc/network/interfaces.d/"$net_name" <<EOF
auto $net_name
allow-hotplug $net_name
iface $net_name inet manual
EOF
  done

  log "Restart networking"
  systemctl restart networking.service &>/dev/null
fi

PORT_COUNT=$(echo "$NET_LIST" | wc -w)

if [ "$PORT_COUNT" -eq 1 ]; then
  log "Only one interface detected. Making a rename."
  rename_port "$NET_LIST" 1
  exit 0
fi

for ((count = 1; count <= "$PORT_COUNT"; count++)); do
  until false; do
    port_find=""
    whiptail --title "Настройка портов CPE" --msgbox "Вставьте кабель ethernet в порт $count. Дождитесь линка и нажмите ОК" 8 78
    for net_name in $NET_LIST; do
      carrier=$(cat /sys/class/net/"${net_name}"/carrier)
      if [ "$carrier" -eq 1 ]; then
        if echo "$PORT_SEQ" | grep -q "$net_name"; then
          break
        else
          PORT_SEQ+="${net_name} "
          port_find=1
          break
        fi
      fi
    done
    if [ $port_find -eq 1 ]; then
      break
    else
      if whiptail --title "Настройка портов CPE" --yesno "Ошибка определения порта $count! Повторить?" 8 78; then
        continue
      else
        die "Could not find port $count"
      fi
    fi
  done
done

PORT_SEQ=${PORT_SEQ// /\\n}

generate_links "$PORT_SEQ"
generate_config "$PORT_SEQ"

log "Enable DHCP-server"
systemctl enable isc-dhcp-server || die "Error enabling isc-dhcp-server"

log "Reboot required"

exit 0
